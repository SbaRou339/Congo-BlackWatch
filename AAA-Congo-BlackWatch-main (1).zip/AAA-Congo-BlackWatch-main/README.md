# AAA-Congo-BlackWatch
Congo is a variant of chess that was invented in the 80s. It contains elements of chess, checkers and shogi (also known as Japanese chess), but the main philosophy is the same: to capture your opponent’s most valuable piece.
